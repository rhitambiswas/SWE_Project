import React from "react";
import {
  ArrowRight, ArrowUpRight, Check, ChevronDown, Menu, X, Sparkles, ShieldCheck, MapPin, Camera, Activity, CloudRain, Flame, Mic, Wind, BrainCircuit, User, Lock, Mail, LogOut, Eye, EyeOff, Thermometer, Droplets, Gauge, Satellite, Video, Table, Bell, Download, Play, Pause, Trash2, RotateCcw, Compass, Navigation, Save, Radio, FileText, Maximize2, Minimize2, AlertTriangle, Settings, HelpCircle, Upload, Paperclip, MessageSquare, Moon, Sun, Monitor, CheckCircle2, Clock3, Send, UserRound, motion, useAnimation, useInView, AnimatePresence, getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, sendEmailVerification, sendPasswordResetEmail, fetchSignInMethodsForEmail, onAuthStateChanged, signOut, updateProfile, reload, EmailAuthProvider, reauthenticateWithCredential, updatePassword, updateEmail, onValue, ref, getStorage, storageRef, uploadBytes, getDownloadURL, firebaseApp, db, firebaseAuth, firebaseStorage, BACKEND_URL, BACKEND_DISPLAY_URL, EMPTY_READING, EMPTY_GPS, NAV_ITEMS, DEFAULT_ALERT_SETTINGS, pm25Status, statusClass, getIaqColor, clamp, fmt, yVal, buildPath, buildAlerts, accountStorageKey, readAccountSettings, readLocalAvatar, saveLocalAvatar, formatAdminTime
} from "../lib/smartSurroundShared.jsx";

import DashboardPreview from "../components/DashboardPreview.jsx";
import { useNavigate } from "../router.jsx";

export default function AuthPage({ onAuthSuccess, onAdminSuccess, onBack, initialMode = "login" }) {

  const navigate = useNavigate();
  const [mode, setMode] = React.useState(initialMode); // "login" | "signup" | "admin"

  React.useEffect(() => {
    setMode(initialMode);
  }, [initialMode]);

  const [showPassword, setShowPassword] = React.useState(false);

  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [adminPin, setAdminPin] = React.useState("");
  const [error, setError] = React.useState("");

  const [showSuccess, setShowSuccess] = React.useState(false);
  const [pendingUser, setPendingUser] = React.useState(null);
  const [successMessage, setSuccessMessage] = React.useState("");
  const [passwordResetSent, setPasswordResetSent] = React.useState(false);
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const setAuthMode = (nextMode) => {
    setMode(nextMode);
    setError("");
    setShowSuccess(false);
    navigate(nextMode === "signup" ? "/register" : nextMode === "admin" ? "/admin-login" : "/login");
  };
  async function handleForgotPassword() {
    setError("");
    setPasswordResetSent(false);

    const cleanEmail = email.trim().toLowerCase();

    if (!cleanEmail) {
      setError("Please enter your email address first.");
      return;
    }

    try {
      setIsSubmitting(true);

      await sendPasswordResetEmail(firebaseAuth, cleanEmail);

      setPasswordResetSent(true);
    } catch (err) {
      console.error("Password reset error:", err.code, err.message);

      if (err?.code === "auth/invalid-email") {
        setError("Please enter a valid email address.");
      } else if (err?.code === "auth/user-not-found") {
        setError("No account was found for this email.");
      } else if (err?.code === "auth/too-many-requests") {
        setError("Too many attempts. Please try again later.");
      } else if (err?.code === "auth/network-request-failed") {
        setError("Network error. Please check your internet connection.");
      } else {
        setError(err?.message || "Unable to send password reset email.");
      }
    } finally {
      setIsSubmitting(false);
    }
  }
  async function handleAdminLogin() {
    const cleanPin = adminPin.trim();

    if (!cleanPin) {
      setError("Please enter the admin PIN.");
      return;
    }

    setIsSubmitting(true);
    setError("");

    try {
      const formData = new URLSearchParams();
      formData.append("pin", cleanPin);

      let response;
      try {
        response = await fetch(`${BACKEND_URL}/login/creds`, {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: formData.toString(),
          cache: "no-store",
        });
      } catch (networkError) {
        throw new Error("Unable to connect to the SmartSurround backend. Start Flask on port 5000 and try again.");
      }

      const contentType = response.headers.get("content-type") || "";
      const data = contentType.includes("application/json") ? await response.json() : null;

      if (!response.ok || !data?.ok) {
        if (response.status === 429) {
          throw new Error(data?.message || "Too many attempts. Please wait and try again later.");
        }
        if (response.status === 403) {
          throw new Error(data?.message || "Invalid admin PIN.");
        }
        throw new Error(data?.message || `Admin login failed (HTTP ${response.status}).`);
      }

      try { window.localStorage.setItem("ss_admin_pin", cleanPin); } catch (_) {}
      try {
        const token = response.headers.get("X-Set-Auth-Token");
        if (token) window.sessionStorage.setItem("ss_admin_token", token);
      } catch (_) {}
      onAdminSuccess?.({ authenticated: true });
    } catch (err) {
      console.error("Admin login error:", err);
      setError(err?.message || "Unable to authenticate as administrator.");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();

    if (mode === "admin") {
      await handleAdminLogin();
      return;
    }

    setError("");

    const cleanName = name.trim();
    const cleanEmail = email.trim().toLowerCase();

    if (!cleanEmail || !password || (mode === "signup" && !cleanName)) {
      setError("Please fill in all fields.");
      return;
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }

    setIsSubmitting(true);

    try {
      if (mode === "signup") {
        // ============================================
        // CREATE FIREBASE ACCOUNT
        // ============================================
        const { user } = await createUserWithEmailAndPassword(
          firebaseAuth,
          cleanEmail,
          password
        );

        // Save the user's name in Firebase Auth profile.
        if (cleanName) {
          await updateProfile(user, {
            displayName: cleanName,
          });
        }

        // Send Firebase email verification.
        await sendEmailVerification(user);

        // Do not allow an unverified account into the dashboard.
        await signOut(firebaseAuth);

        setPendingUser({
          name: cleanName || cleanEmail.split("@")[0],
          email: cleanEmail,
        });

        setSuccessMessage(
          "We sent a verification link to your email. Verify your email, then log in to continue."
        );

        setShowSuccess(true);
      } else {
        // ============================================
        // LOGIN
        // ============================================
        const { user } = await signInWithEmailAndPassword(
          firebaseAuth,
          cleanEmail,
          password
        );

        // Refresh the user so emailVerified is current.
        await reload(user);

        if (!user.emailVerified) {
          await signOut(firebaseAuth);

          setError(
            "Your email is not verified yet. Open the verification email we sent you, verify your email, then log in again."
          );

          return;
        }

        setPendingUser({
          name:
            user.displayName ||
            cleanEmail.split("@")[0],
          email: user.email || cleanEmail,
        });

        setSuccessMessage(
          "Your email is verified. Taking you to your live dashboard..."
        );

        setShowSuccess(true);
      }
    } catch (err) {
      console.error("Firebase authentication error:", err);

      const code = err?.code || "";

      if (code === "auth/email-already-in-use") {
        setError("An account with this email already exists. Please log in.");
      } else if (code === "auth/invalid-email") {
        setError("Please enter a valid email address.");
      } else if (code === "auth/invalid-credential" || code === "auth/wrong-password" || code === "auth/user-not-found") {
        setError("Invalid email or password.");
      } else if (code === "auth/too-many-requests") {
        setError("Too many attempts. Please wait a while and try again.");
      } else if (code === "auth/network-request-failed") {
        setError("Network error. Please check your internet connection.");
      } else {
        setError(err?.message || "Authentication failed. Please try again.");
      }
    } finally {
      setIsSubmitting(false);
    }
  }

  React.useEffect(() => {
    if (!showSuccess || !pendingUser) return;

    // Signup must NOT automatically enter the dashboard because
    // the user still needs to verify their email first.
    if (mode === "signup") return;

    const timer = setTimeout(() => {
      onAuthSuccess(pendingUser);
    }, 1700);

    return () => clearTimeout(timer);
  }, [showSuccess, pendingUser, mode, onAuthSuccess]);

  function closeSuccess() {
    setShowSuccess(false);
    setPendingUser(null);
    setSuccessMessage("");

    if (mode === "signup") {
      setAuthMode("login");
      setPassword("");
      setError("");
    }
  }

  return (
    <section className="auth-section">

      <div className="auth-glow"></div>

      <div className="auth-layout">

        <motion.div
          className="auth-box"
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >

          <button type="button" className="auth-back" onClick={onBack}>
            <ArrowRight size={14} style={{ transform: "rotate(180deg)" }} />
            Back to site
          </button>

          <div className="auth-brand">
            <div className="brand-icon">
              <Activity size={19} strokeWidth={2.5} />
            </div>

            <div>
              <span className="brand-name">Smart</span>
              <span className="brand-name-light">Surround</span>
            </div>
          </div>

          <div className="auth-heading">
            <h2>
              {mode === "admin" ? "Administrator login" : mode === "login" ? "Welcome back" : "Create your account"}
            </h2>

            <p>
              {mode === "admin"
                ? "Use the secure administrator PIN to open the SmartSurround control panel."
                : mode === "login"
                  ? "Log in to view your live monitoring dashboard."
                  : "Sign up to start monitoring your surroundings."}
            </p>
          </div>

          <div className="auth-tabs">
            <button
              type="button"
              className={mode === "login" ? "active" : ""}
              onClick={() => {
                setAuthMode("login");
                setError("");
                setShowSuccess(false);
              }}
            >
              Log In
            </button>

            <button
              type="button"
              className={mode === "admin" ? "active" : ""}
              onClick={() => {
                setAuthMode("admin");
                setError("");
                setShowSuccess(false);
              }}
            >
              Admin Login
            </button>

            <button
              type="button"
              className={mode === "signup" ? "active" : ""}
              onClick={() => {
                setAuthMode("signup");
                setError("");
                setShowSuccess(false);
              }}
            >
              Create Account
            </button>
          </div>

          <form className="auth-form" onSubmit={handleSubmit}>

            {mode === "admin" ? (
              <label className="auth-field">
                <span>Admin PIN</span>
                <div className="auth-input">
                  <ShieldCheck size={16} />
                  <input
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter administrator PIN"
                    value={adminPin}
                    onChange={(e) => setAdminPin(e.target.value)}
                    autoComplete="current-password"
                    inputMode="numeric"
                  />
                  <button
                    type="button"
                    className="auth-eye"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label={showPassword ? "Hide admin PIN" : "Show admin PIN"}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </label>
            ) : (
              <>
            {mode === "signup" && (
              <label className="auth-field">
                <span>Full Name</span>

                <div className="auth-input">
                  <User size={16} />
                  <input
                    type="text"
                    placeholder="Jordan Rivera"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    autoComplete="name"
                  />
                </div>
              </label>
            )}

            <label className="auth-field">
              <span>Email</span>

              <div className="auth-input">
                <Mail size={16} />
                <input
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                />
              </div>
            </label>

            <label className="auth-field">
              <span>Password</span>

              <div className="auth-input">
                <Lock size={16} />
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete={mode === "login" ? "current-password" : "new-password"}
                />
                <button
                  type="button"
                  className="auth-eye"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </label>

            </>
            )}

            {mode === "login" && (
              <div className="forgot-password-row">
                <button
                  type="button"
                  className="forgot-password-button"
                  onClick={handleForgotPassword}
                  disabled={isSubmitting}
                >
                  Forgot password?
                </button>
              </div>
            )}
            {mode === "login" && passwordResetSent && (
              <div className="password-reset-success">
                <div className="password-reset-success-title">
                  Check your email
                </div>

                <div className="password-reset-success-text">
                  We’ve sent a password reset link to your email address.
                  Please check your inbox and spam folder.
                </div>
              </div>
            )}


            {error && <div className="auth-error">{error}</div>}

            <button
              type="submit"
              className="primary-button auth-submit"
              disabled={isSubmitting}
              style={{ opacity: isSubmitting ? 0.7 : 1 }}
            >
              {isSubmitting
                ? "Please wait..."
                : mode === "admin"
                  ? "Open Admin Panel"
                  : mode === "login"
                    ? "Log In"
                    : "Create Account"}
              <ArrowRight size={16} />
            </button>

          </form>

          <div className="auth-switch">
            {mode === "admin" ? (
              <>
                Need a regular account?
                <button type="button" onClick={() => setAuthMode("login")}>
                  User login
                </button>
              </>
            ) : mode === "login" ? (
              <>
                Don't have an account?
                <button type="button" onClick={() => setAuthMode("signup")}>
                  Create one
                </button>
              </>
            ) : (
              <>
                Already have an account?
                <button type="button" onClick={() => setAuthMode("login")}>
                  Log in
                </button>
              </>
            )}
          </div>

        </motion.div>

        <motion.div
          className="auth-showcase"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.15 }}
        >

          <div className="section-tag light">
            <span></span>
            WHAT YOU GET
          </div>

          <h3>
            Your live monitoring
            <br />
            dashboard, ready to go.
          </h3>

          <p>
            Air quality, AI vision, sound and location intelligence —
            all in one unified, real-time view.
          </p>

          <DashboardPreview />

        </motion.div>

      </div>

      {showSuccess && (
        <motion.div
          className="auth-success-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          onClick={mode === "signup" ? closeSuccess : undefined}
        >

          <motion.div
            className="auth-success-card"
            initial={{ opacity: 0, scale: 0.85, y: 16 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
            onClick={(e) => e.stopPropagation()}
          >

            <motion.div
              className="auth-success-icon"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.4, delay: 0.15, type: "spring" }}
            >
              <Check size={26} strokeWidth={3} />
            </motion.div>

            <h3>
              {mode === "login" ? "Login successful" : "Verify your email"}
            </h3>

            <p>
              {successMessage}
            </p>

            {mode === "signup" && (
              <button
                type="button"
                className="primary-button auth-submit"
                onClick={closeSuccess}
              >
                Continue to Login
                <ArrowRight size={16} />
              </button>
            )}

            {mode === "login" && (
              <div className="auth-success-bar">
                <motion.div
                  className="auth-success-bar-fill"
                  initial={{ width: "0%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 1.6, ease: "linear" }}
                />
              </div>
            )}

          </motion.div>

        </motion.div>
      )}

    </section>
  );
}



/* =========================================================
   LIVE DASHBOARD — SHARED HELPERS
========================================================= */

